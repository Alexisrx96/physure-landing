"""Domain layer for physure."""
