"""physure Physics-Informed Neural Networks (physure.nn)."""
